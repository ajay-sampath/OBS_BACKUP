---
area:
  - Personal Growth
Progress: 2
Target: 26
Start: 
Deadline: 2025-12-31
banner: "https://miro.medium.com/v2/resize:fit:1400/1*f18XL9B9tK2OU5Z9uQWFcQ.png"
banner_y: 0.244
Completed date: 
---
```meta-bind
INPUT[progressBar(title(Progress), minValue(0), maxValue(26)):Progress]
```

> [!info]- Why is this goal Important to me?
> - 1
> - 2

> [!success]- What would I gain by achieving this goal?
> - 1
> - 2

> [!danger]- What are the possible risks & Obstacles?
> - 1
> - 2




