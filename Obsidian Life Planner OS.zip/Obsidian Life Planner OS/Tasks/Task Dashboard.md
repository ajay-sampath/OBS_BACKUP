```dataviewjs
await dv.view("Tasks/Timeline", {pages: "", forward: true, options: "noYear noInfo todayFocus"})
```

