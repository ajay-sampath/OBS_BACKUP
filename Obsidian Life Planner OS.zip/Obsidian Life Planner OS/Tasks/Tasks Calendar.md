```dataviewjs
await dv.view("Tasks/Calendar", {pages: "", view: "month", firstDayOfWeek: "1", options: "style1"})
```

